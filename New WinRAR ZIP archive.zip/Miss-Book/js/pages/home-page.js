export default {
    template: `
        <section class="home-page app-main">
            <div class="main-layout">
                <h2>Best books eu-west!</h2>
            </div>
        </section>
    `
}