export default {
    template: `
    <section>
        <h1>Yes we are a real team indeed</h1>
    </section>
    `,
}