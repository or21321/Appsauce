export default {
    template: `
    <header class="app-header-container">
        <div class="app-header main-layout">
            <div class="logo">
                <h3>Books</h3>
            </div>
            <nav>
                <!-- ? how to fix active styling -->
                <router-link to="/" active-class="active-link">Home</router-link>
                <router-link to="/book">Books</router-link>
                <router-link to="/about">About</router-link>
            </nav>
        </div>
    </header>
    `,
};
