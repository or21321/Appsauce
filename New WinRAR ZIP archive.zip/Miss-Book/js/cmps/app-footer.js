export default {
    template: `
    <footer class="app-footer">
        <div class="main-layout">
            <p>&copy; Coffeerights</p>
        </div>
    </footer>
    `,
};

